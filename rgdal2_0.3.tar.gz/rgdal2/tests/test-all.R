library(testthat)
test_check("rgdal2")
